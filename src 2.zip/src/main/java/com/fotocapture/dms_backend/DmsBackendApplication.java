package com.fotocapture.dms_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class DmsBackendApplication {
	public static void main(String[] args) {
		SpringApplication.run(DmsBackendApplication.class, args);
	}
}
