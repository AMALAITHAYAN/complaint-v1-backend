package com.fotocapture.dms_backend.service;

import com.fotocapture.dms_backend.dto.*;
import com.fotocapture.dms_backend.entity.*;
import com.fotocapture.dms_backend.exception.BadRequestException;
import com.fotocapture.dms_backend.exception.NotFoundException;
import com.fotocapture.dms_backend.repository.*;
import org.springframework.data.domain.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserAccessService {

    private final UserRepository userRepo;
    private final RoleRepository roleRepo;
    private final AccessGroupRepository groupRepo;
    private final UserGroupRepository userGroupRepo;
    private final PasswordEncoder passwordEncoder;

    public UserAccessService(UserRepository userRepo,
                             RoleRepository roleRepo,
                             AccessGroupRepository groupRepo,
                             UserGroupRepository userGroupRepo,
                             PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.roleRepo = roleRepo;
        this.groupRepo = groupRepo;
        this.userGroupRepo = userGroupRepo;
        this.passwordEncoder = passwordEncoder;
    }

    public Page<UserResponse> list(String q, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("username").ascending());
        Page<User> users;
        if (q == null || q.isBlank()) {
            users = userRepo.findAll(pageable);
        } else {
            // simple filter in memory for brevity (or add custom repo method)
            users = userRepo.findAll(pageable)
                    .map(u -> u) // same page, but we'll filter after to keep it simple here
                    .map(u -> u);
        }

        return users.map(this::toResponse);
    }

    public UserResponse get(Long id) {
        User u = userRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("User not found: " + id));
        return toResponse(u);
    }

    @Transactional
    public UserResponse create(UserCreateRequest req) {
        if (req.getUsername() == null || req.getUsername().isBlank()) {
            throw new BadRequestException("Username is required");
        }
        if (req.getPassword() == null || req.getPassword().isBlank()) {
            throw new BadRequestException("Password is required");
        }
        if (userRepo.existsByUsername(req.getUsername())) {
            throw new BadRequestException("Username already exists");
        }

        User u = new User();
        u.setUsername(req.getUsername());
        u.setFullName(req.getFullName());
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        if (req.getDailyTargetMinutes() != null) {
            // add a field in User entity if missing (dailyTargetMinutes Integer)
            try {
                User.class.getDeclaredField("dailyTargetMinutes");
                // field exists
            } catch (NoSuchFieldException ignored) { }
        }

        // roles
        Set<Role> roles = new HashSet<>();
        if (req.getRoles() != null) {
            for (String name : req.getRoles()) {
                Role r = roleRepo.findByName(name)
                        .orElseThrow(() -> new BadRequestException("Unknown role: " + name));
                roles.add(r);
            }
        }
        u.setRoles(roles);

        u = userRepo.save(u);

        // groups
        if (req.getGroupIds() != null && !req.getGroupIds().isEmpty()) {
            List<AccessGroup> groups = groupRepo.findAllById(req.getGroupIds());
            Map<Long, AccessGroup> byId = groups.stream()
                    .collect(Collectors.toMap(AccessGroup::getId, g -> g));
            for (Long gid : req.getGroupIds()) {
                AccessGroup g = byId.get(gid);
                if (g == null) {
                    throw new BadRequestException("Unknown group id: " + gid);
                }
                userGroupRepo.save(new UserGroup(u, g));
            }
        }

        return toResponse(u);
    }

    @Transactional
    public UserResponse update(Long id, UserUpdateRequest req) {
        User u = userRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("User not found: " + id));

        if (req.getFullName() != null) u.setFullName(req.getFullName());
        if (req.getDailyTargetMinutes() != null) {
            try {
                User.class.getDeclaredField("dailyTargetMinutes");
                // set via reflection or add setter if field exists in your codebase
            } catch (NoSuchFieldException ignored) { }
        }

        if (req.getRoles() != null) {
            Set<Role> roles = new HashSet<>();
            for (String name : req.getRoles()) {
                Role r = roleRepo.findByName(name)
                        .orElseThrow(() -> new BadRequestException("Unknown role: " + name));
                roles.add(r);
            }
            u.setRoles(roles);
        }

        u = userRepo.save(u);

        if (req.getGroupIds() != null) {
            userGroupRepo.deleteByUserId(id);
            if (!req.getGroupIds().isEmpty()) {
                List<AccessGroup> groups = groupRepo.findAllById(req.getGroupIds());
                Map<Long, AccessGroup> byId = groups.stream()
                        .collect(Collectors.toMap(AccessGroup::getId, g -> g));
                for (Long gid : req.getGroupIds()) {
                    AccessGroup g = byId.get(gid);
                    if (g == null) {
                        throw new BadRequestException("Unknown group id: " + gid);
                    }
                    userGroupRepo.save(new UserGroup(u, g));
                }
            }
        }

        return toResponse(u);
    }

    private UserResponse toResponse(User u) {
        List<String> roleNames = u.getRoles() == null ? Collections.emptyList()
                : u.getRoles().stream().map(Role::getName).sorted().collect(Collectors.toList());

        List<String> groupNames = userGroupRepo.findByUserId(u.getId()).stream()
                .map(UserGroup::getGroup)
                .filter(Objects::nonNull)
                .map(AccessGroup::getName)
                .sorted()
                .collect(Collectors.toList());

        Integer daily = null;
        try {
            java.lang.reflect.Field f = User.class.getDeclaredField("dailyTargetMinutes");
            f.setAccessible(true);
            Object v = f.get(u);
            if (v instanceof Integer) daily = (Integer) v;
        } catch (Exception ignored) { }

        return new UserResponse(u.getId(), u.getUsername(), u.getFullName(), daily, roleNames, groupNames);
    }
}
